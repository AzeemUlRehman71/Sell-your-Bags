<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Http\Requests\StoreClientRequest;
use App\Http\Requests\UpdateClientRequest;
use App\Jobs\SendPoEmail;
use App\Mail\ThankYou;
use App\Models\Product;
use App\Models\TemporarayFile;
use Intervention\Image\Facades\Image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

use GuzzleHttp\Handler\Proxy;

//use GuzzleHttp\Psr7\Response;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use PHPUnit\Framework\Constraint\Count;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Auth;


use Illuminate\Support\Facades\Response;


class ClientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Client $client)
    {
        $list = $client->getAllClientsWithProducts();
        $data = DB::table('users_role')->where('user_role', Auth::user()->user_role)->get();
        return view('backend.client.index', compact('list', 'data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('frontend/pages/sellyourbags');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreClientRequest  $request
     * @return \Illuminate\Http\Response
     */

    public function filepondprocess(Request $request)
    {
        $products = $request->products;

        if ($request->has('id_card_image')) {
            $idcard = $request->file('id_card_image');
            $file_name = $idcard->getClientOriginalName();
            $folder = uniqid('post', true);

            //saving images in storage but giveing issues on production
            //$idcard->storeAs('posts/tmp/' .$folder,$file_name);

            //so saving images in Public folder now 
            $idcard->move(public_path('posts/tmp/') . $folder, $file_name);
            TemporarayFile::create([
                'folder' => $folder,
                'file' => $file_name
            ]);

            return $folder;
        }

        if ((!empty($products[0]["'image'"]))) {
            $product1 = $products[0]["'image'"];
            $file_name = $product1->getClientOriginalName();
            $folderProduct1 = uniqid('product', true);
            //$product1->storeAs('products/tmp/' .$folderProduct1,$file_name);
            $product1->move(public_path('products/tmp/') . $folderProduct1, $file_name);
            TemporarayFile::create([
                'folder' => $folderProduct1,
                'file' => $file_name
            ]);

            return $folderProduct1;
        }
        if ((!empty($products[1]["'image'"]))) {

            $product2 = $products[1]["'image'"];
            $file_name = $product2->getClientOriginalName();
            $folderProduct2 = uniqid('product', true);
            //$product2->storeAs('products/tmp/' .$folderProduct2,$file_name);
            $product2->move(public_path('products/tmp/') . $folderProduct2, $file_name);
            TemporarayFile::create([
                'folder' => $folderProduct2,
                'file' => $file_name
            ]);

            return $folderProduct2;
        }
        if ((!empty($products[2]["'image'"]))) {

            $product3 = $products[2]["'image'"];
            $file_name = $product3->getClientOriginalName();
            $folderProduct3 = uniqid('product', true);
            //  $product3->storeAs('products/tmp/' .$folderProduct3,$file_name);
            $product3->move(public_path('products/tmp/') . $folderProduct3, $file_name);

            TemporarayFile::create([
                'folder' => $folderProduct3,
                'file' => $file_name
            ]);

            return $folderProduct3;
        }
        return '';
    }
    public function filepondDelete(Request $request)
    {

        $fileId = request()->getContent();
        $productDel = Str::startsWith($fileId, 'product');
        $postDel = Str::startsWith($fileId, 'post');

        if ($productDel) {
            $tmp_file = TemporarayFile::where('folder', $fileId)->first();
            if ($tmp_file) {
                //  Storage::deleteDirectory('/products/tmp/' .$tmp_file->folder);
                File::deleteDirectory(public_path('/products/tmp/') . $tmp_file->folder);
                $tmp_file->delete();
            }
        }
        if ($postDel) {
            $tmp_file = TemporarayFile::where('folder', $fileId)->first();
            if ($tmp_file) {
                // $realPath1=$tmp_file->folder . '/' .$tmp_file->file;
                //   Storage::deleteDirectory('/posts/tmp/' .$tmp_file->folder);
                File::deleteDirectory(public_path('/posts/tmp/') . $tmp_file->folder);
                $tmp_file->delete();
            }
        }
    }



    public function filepondRestore(Request $request, string $id)
    {

        //$fileId = $request->id;
        // dd($fileId);

        // $path = 'posts/tmp/'.$id.'/presentation_1.png';
        // dd(storage_path());
        // dd($path);
        // if (file_exists(storage_path().'/app/posts/tmp/'.$id.'/presentation_1.png')) {
        //     dd('File  Exists');
        //   }else{
        //     dd('File  Not Exists');
        //   }

        // dd(Storage::disk('local')->exists($path));
        //  if (Storage::exists(storage_path().'/app/posts/tmp/'.$id.'/presentation_1.png')) {
        //     dd('File  Exists');
        //   }else{
        //     dd('File  Not Exists');
        //   }


        // $heredisk = config('filesystems.disks.local.root');
        //dd($heredisk);

        // $path = 'posts/tmp/'.$id.'/presentation_1.png';
        // dd($path);

        // $mime = Storage::disk('local')->mimeType($path);
        // $file = Storage::disk('local')->get($path);

        // return Response::make($file, 200, [
        //     'Content-Type' => $mime,
        //     'Content-Disposition' => 'inline; filename="'.$id.'"',
        // ]);



    }
    public function store(Request $request)
    {
        // dd($request->all());
        $formNo = config('constants.options.Form_No');
        $clientsCount = DB::table('clients')->count();
        if ($clientsCount > 0) {

            $clientLast = Client::orderBy('po_number', 'desc')->first();
            $lastPo = $clientLast->po_number;
            $poNumberNext = $lastPo + 1;
        } else {
            $poNumberNext = config('constants.options.Form_No');
        }

        $input = $request->all();
        $file = $request->file('productImage');

        $ids = $request->productName;

        if ($request->payment_method == 'direct') {

            $payment_name = $request->payment_full_name;
            $payment_email = $request->payment_email;
            $payment_direct_phone_number = $request->payment_direct_phone_number;
            $payment_direct_account_number = $request->payment_direct_account_number;
            $payment_direct_routing_number = $request->payment_direct_routing_number;
            $payment_direct_account_type = $request->payment_direct_account_type;
            $payment_direct_bank_name = $request->payment_direct_bank_name;
        }
        if ($request->payment_method == 'paypal') {
            $payment_name = $request->payment_name_paypal;
            $payment_email = $request->payment_email_paypal;
        }
        if ($request->payment_method == 'cheque') {
            $payment_name = $request->payment_full_name_cheque;
            $payment_email = $request->payment_email_cheque;
        }
        if ($request->payment_method == 'echeck') {
            $payment_name = $request->payment_full_name_echeck;
            $payment_email = $request->payment_email_echeck;
        }
        if ($request->payment_method == 'storecredit') {
            $store_credit = $request->storecredit;
            $payment_name = $request->payment_full_name;
            $payment_email = $request->payment_email;
            $payment_direct_phone_number = $request->payment_direct_phone_number;
            $payment_direct_account_number = $request->payment_direct_account_number;
            $payment_direct_routing_number = $request->payment_direct_routing_number;
            $payment_direct_account_type = $request->payment_direct_account_type;
            $payment_direct_bank_name = $request->payment_direct_bank_name;
        }

        $folderPath = public_path('signature/');
        $imageParts = explode(";base64,", $request->signature64);
        $imageTypeAux = explode("image/", $imageParts[0]);
        $imageType = $imageTypeAux[1];
        $imageBase64 = base64_decode($imageParts[1]);
        $imageName = 'signature' . '_' . microtime() . '.' . $imageType;
        $file = $folderPath . $imageName;
        file_put_contents($file, $imageBase64);



        $tmp_file = TemporarayFile::where('folder', $request->id_card_image)->first();

        $realPath1 = '';
        if ($tmp_file) {

            Storage::copy('/posts/tmp/' . $tmp_file->folder . '/' . $tmp_file->file, '/idcard/' . $tmp_file->folder . '/' . $tmp_file->file);

            $realPath1 = $tmp_file->folder . '/' . $tmp_file->file;
            File::deleteDirectory(public_path('/posts/tmp/') . $tmp_file->folder);
            $tmp_file->delete();
        }

        $client = new Client();

        $client->name = $request->input('name');
        $client->email = $request->input('email');
        $client->phone = $request->input('phone');
        $client->address = $request->input('address');
        $client->user_create = Auth::user()->name;
        $client->id_card_image = $realPath1 ?? null;
        $client->payment_method = $request->input('payment_method');
        $client->payment_full_name = $payment_name;
        $client->payment_email = $payment_email;
        $client->payment_direct_phone_number = $payment_direct_phone_number ?? null;
        $client->payment_direct_account_number = $payment_direct_account_number ?? null;
        $client->payment_direct_routing_number = $payment_direct_routing_number ?? null;
        $client->payment_direct_account_type = $payment_direct_account_type ?? null;
        $client->payment_direct_bank_name = $payment_direct_bank_name ?? null;
        $client->store_credit = $store_credit ?? null;
        $client->client_status = 'Pending';
        $client->total_amount = $request->input('grand_total');
        $client->signature = $imageName;
        $client->disclaimer = 1;
        $client->po_number = $poNumberNext;
        $client->note = $request->input('note');

        $client->save();

        $lastId = $client->id;
        $newPo = $client->po_number;
        $condition = $request->productImage;
        $products = $request->products;

        $newArray = collect($products)->reject(function ($product) {
            return is_null($product["'name'"]) && is_null($product["'condition'"]) && is_null($product["'price'"]);
        });

        foreach ($newArray as  $product) {

            if ((!empty($product["'image'"]))) {
                $tmp_file = TemporarayFile::where('folder', $product["'image'"])->first();
                if ($tmp_file) {
                    Storage::copy('/products/tmp/' . $tmp_file->folder . '/' . $tmp_file->file, '/product/' . $tmp_file->folder . '/' . $tmp_file->file);
                    $realPath = $tmp_file->folder . '/' . $tmp_file->file;
                    File::deleteDirectory(public_path('/products/tmp/') . $tmp_file->folder);
                    $tmp_file->delete();
                } else {

                    $realPath = '';
                }
            }

            $productNew = new Product();
            $productNew->name = $product["'name'"] ?? '';;
            $productNew->condition = $product["'condition'"] ?? '';
            $productNew->price = $product["'price'"];
            $productNew->client_id = $lastId;
            $productNew->image_path = $realPath ?? '';
            $productNew->save();
        }

        $clientDetails = Client::with('product')->find($lastId);

        return redirect()->route('sellyourbags.thankyou', ['id' => $lastId, 'po' => $newPo]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Client  $client
     * @return \Illuminate\Http\Response
     */
    public function show($id, Client $client)
    {

        $clientDetails = $client->getClientDetailsById($id);

         $backClient = Client::where('id', '<', $id)->orderBy('id', 'desc')->first();
         $nextClient = Client::where('id', '>', $id)->orderBy('id', 'asc')->first();

        return view('backend/client/view', ['clientDetails' => $clientDetails, 'backClient' => $backClient, 'nextClient' => $nextClient]);
    }

    public function showimg($folder, $img)
    {
        $folders = $folder;
        $imgs = $img;
        return view('backend/client/view', ['folders' => $folders]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Client  $client
     * @return \Illuminate\Http\Response
     */

    public function editProductUnit(Request $request)
    {
        $this->validate($request, [

            'edit_product_id' => 'required',
            'client_status' => 'required'
        ]);

        DB::beginTransaction();
        try {

            $client = Client::where('id', $request->edit_product_id)->first();
            Client::where('id', $client->id)->update([
                'client_status' => $request->client_status
            ]);

            DB::commit();
            return redirect()->back()->with('clientupdated', __('Client Status Updated Successfully'));
        } catch (\Exception $e) {
            DB::rollback();
            return redirect()->back()->with('danger', __('Something went Wrong'));
        }
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Client  $client
     * @return \Illuminate\Http\Response
     */

    public function editProductDetails(Request $request)
    {
        $this->validate($request, [
            'productPrice_value' => 'required',
            'productImage_value' => 'sometimes|nullable|image|mimes:jpg,jpeg,png',
        ]);

        DB::beginTransaction();
        try {

            $product = Product::where('id', $request->edit_product_id_value)->first();
            $string = $product->image_path;
            //Get the product folder name i-e extract from it
            $token = strtok($string, "/"); // Output   
            $client = Client::where('id', $request->client_id_value)->first();

            if ($request->hasFile('productImage_value')) {

                $originalImage = $request->file('productImage_value');
                $thumbnailImage = Image::make($originalImage);
                //  $thumbnailPath = public_path().'/products/';
                $thumbnailPath = 'product/' . $token . '/';
                // $originalPath = public_path().'/images/';
                //$thumbnailImage->save($originalPath.time().$originalImage->getClientOriginalName());
                // $thumbnailImage->resize(400, 200);
                $thumbnailImage->fit(600, 360, function ($constraint) {
                    $constraint->upsize();
                });
                $thumbnailImage->save($thumbnailPath . time() . $originalImage->getClientOriginalName());
                //  dd($thumbnailPath.time().$originalImage->getClientOriginalName());
                $realPath = $token . '/' . time() . $originalImage->getClientOriginalName();
                $realPathnnnn = $thumbnailPath . $originalImage->getClientOriginalName();
            }
            // dd($realPath);
            Product::where('id', $product->id)->update([

                'condition' => $request->productCondition ?? null,
                'price' => $request->productPrice_value,
                'name' => $request->productName ?? null,
                'image_path' => $realPath ?? $request->product_image_value
            ]);

            $productAll = Product::all()->where('client_id', '=', $request->client_id_value);

            $sum = 0;
            foreach ($productAll as $calProduct) {

                $sum += $calProduct['price'];
            }

            Client::where('id', $client->id)->update([

                'total_amount' => $sum,
            ]);
            DB::commit();

            return redirect()->back()->with('productUpdated', __('Product Updated Successfully'));
        } catch (\Exception $e) {
            dd($e);
            DB::rollback();

            return redirect()->back()->with('danger', __('Something went Wrong'));
        }
    }

    public function editClient($id)
    {

        $clientDetails = Client::with('product')->find($id);

        return view('backend/client/edit', ['clientDetails' => $clientDetails]);
    }

    /**
     * Update a  resource in storage.
     *
     * @param  \App\Http\Requests\UpdateClientRequest  $request
     * @return \Illuminate\Http\Response
     */

    public function update(UpdateClientRequest $request, $id)
    {
        DB::beginTransaction();
        try {

            $client = Client::where('id', $request->id)->first();
            $string = $client->id_card_image;
            $token = strtok($string, "/"); // Output: Thequickbrown

            if ($request->has('id_card_image')) {
                $originalImage = $request->file('id_card_image');
                $thumbnailImage = Image::make($originalImage);
                $thumbnailPath = 'idcard/' . $token . '/';
                // $originalPath = public_path().'/images/';
                //$thumbnailImage->save($originalPath.time().$originalImage->getClientOriginalName());
                // $thumbnailImage->resize(400, 200);
                // $thumbnailImage->resize(500, 350, function ($constraint) {
                //     $constraint->aspectRatio();
                //     $constraint->upsize();
                // });
                $thumbnailImage->fit(600, 360, function ($constraint) {
                    $constraint->upsize();
                });
                $thumbnailImage->save($thumbnailPath . time() . $originalImage->getClientOriginalName());
                // $realPath =time().$originalImage->getClientOriginalName();
                $realPath = $token . '/' . time() . $originalImage->getClientOriginalName();
                Client::where('id', $client->id)->update([
                    'id_card_image' => $realPath,
                ]);
            }

            if ($request->filled('signature64')) {
                $folderPath = public_path('signature/');
                $imageParts = explode(";base64,", $request->signature64);
                $imageTypeAux = explode("image/", $imageParts[0]);
                $imageType = $imageTypeAux[1];
                $imageBase64 = base64_decode($imageParts[1]);
                $imageName = 'signature' . '_' . microtime() . '.' . $imageType;
                $file = $folderPath . $imageName;
                file_put_contents($file, $imageBase64);
            }

            if ($request->payment_method == 'direct') {

                $payment_name = $request->payment_full_name;
                $payment_email = $request->payment_email;
                $payment_direct_phone_number = $request->payment_direct_phone_number;
                $payment_direct_account_number = $request->payment_direct_account_number;
                $payment_direct_routing_number = $request->payment_direct_routing_number;
                $payment_direct_account_type = $request->payment_direct_account_type;
                $payment_direct_bank_name = $request->payment_direct_bank_name;
            }
            if ($request->payment_method == 'paypal') {
                $payment_name = $request->payment_name_paypal;
                $payment_email = $request->payment_email_paypal;
            }
            if ($request->payment_method == 'cheque') {
                $payment_name = $request->payment_full_name_cheque;
                $payment_email = $request->payment_email_cheque;
            }
            if ($request->payment_method == 'echeck') {
                $payment_name = $request->payment_full_name_echeck;
                $payment_email = $request->payment_email_echeck;
            }
            if ($request->payment_method == 'storecredit') {
                $store_credit = $request->storecredit;
                $payment_name = $request->payment_full_name;
                $payment_email = $request->payment_email;
                $payment_direct_phone_number = $request->payment_direct_phone_number;
                $payment_direct_account_number = $request->payment_direct_account_number;
                $payment_direct_routing_number = $request->payment_direct_routing_number;
                $payment_direct_account_type = $request->payment_direct_account_type;
                $payment_direct_bank_name = $request->payment_direct_bank_name;
            }

            Client::where('id', $client->id)->update([
                'name' => $request->name,
                'email' => $request->email,
                'phone' => $request->phone,
                'address' => $request->address,
                'user_create' => Auth::user()->name,
                'payment_method' => $request->payment_method,
                'payment_full_name' => $payment_name ? $payment_name : $request->payment_full_name,
                'payment_email' => $payment_email ? $payment_email : $request->payment_email,
                'payment_direct_phone_number' => $payment_direct_phone_number ?? $request->payment_direct_phone_number,
                'payment_direct_account_number' => $payment_direct_account_number ?? $request->payment_direct_account_number,
                'payment_direct_routing_number' => $payment_direct_routing_number ?? $request->payment_direct_routing_number,
                'payment_direct_account_type' => $payment_direct_account_type ?? $request->payment_direct_account_type,
                'payment_direct_bank_name' => $payment_direct_bank_name ?? $request->payment_direct_bank_name,
                'store_credit' => $store_credit ?? $request->storecredit,
                'signature' => $imageName ?? $request->oldsignature,
                'note' => $request->note,
            ]);

            DB::commit();

            return redirect()->back()->with('clientdetailsupdated', __('Client Details Updated Successfully'));
        } catch (\Exception $e) {
            // dd($e);

            DB::rollback();

            return redirect()->back()->with('danger', __('Something went Wrong'));
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Client  $client
     * @return \Illuminate\Http\Response
     */
    public function destroy(Client $client)
    {
        //
    }

    public function thankyou($id)
    {
        return view('frontend/pages/thankyou', ['id' => $id]);
    }

    public function print($id)
    {
        $clientDetails = Client::with('product')->find($id);
        return view('frontend/pages/thankyouprint', ['clientDetails' => $clientDetails]);
    }
}
