<!-- Modal -->
<div class="modal fade" id="edit_product_details" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="post" action="{{ route('client.edit_product_details') }}" enctype="multipart/form-data">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Product Details</h5>
                    <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <input type="hidden" id="edit_product_id_value" name="edit_product_id_value">
                                <input type="hidden" id="total_amount_value" name="total_amount_value">
                                <input type="hidden" id="client_id_value" name="client_id_value">
                                <input type="hidden" id="product_image_value" name="product_image_value">
                                {{-- <input type="hidden" id="newTotal" name="newTotal"> --}}
                                <label class="form-label">Proudct Condition</label>
                                <select class="form-select shadow-none" aria-label="Default select example"
                                    name="productCondition" id="productCondition_value">
                                    <option value="">Conditon Rank</option>
                                    <option value="A(Mint)">A(Mint)</option>
                                    <option value="AB(Ecellent)">AB(Ecellent)</option>
                                    <option value="B(Gently Used)">B(Gently Used)</option>
                                    <option value="BC(Used)">BC(Used)</option>
                                    <option value="C(Well Used)">C(Well Used)</option>
                                    <option value="D(Need Prayers)">D(Need Prayers)</option>

                                </select>
                            </div>
                        </div>

                        <div class="row mt-1">
                            <div class="col-md-12">
                                <label class="form-label">Item Name</label>
                                <input type="text" class="form-control" name="productName" id="productName_value">
                            </div>

                        </div>

                        <div class="row mt-1">
                            <div class="col-md-12">
                                <label class="form-label" for="productPrice_value">Price <b
                                        class="text-danger">*</b></label>
                                <input type="number"  class="form-control"
                                    name="productPrice_value" id="productPrice_value" required>
                            </div>

                        </div>
                        <div class="row mt-1">
                            <div class="col-md-12">
                                <img src="{{ asset('/products/' . $clientDetails->id_card_image) }}" />
                                <label class="form-label">Image</label>
                                <input type="file" class="form-control" name="productImage_value"
                                    id="productImage_value">
                            </div>

                        </div>
                        {{-- <div class="row mt-1">
                            <div class="col-md-12">
                                <label class="form-label" for="newTotal">New Total</label>
                                <input type="text" readonly class="form-control" name="newTotal" id="newTotal">
                            </div>

                        </div> --}}
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-success" type="submit">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
