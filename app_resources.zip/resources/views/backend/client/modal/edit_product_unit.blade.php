<!-- Modal -->
<div class="modal fade" id="edit_unit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="post" action="{{ route('client.edit_unit') }}">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Pos Status</h5>
                    <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <input type="hidden" id="edit_product_id" name="edit_product_id">
                                <label class="form-label">Status</label>
                                {{-- <input type="text" class="form-control" name="unit_name" id="unit_names"
                                    value="unit_names" required placeholder="Enter Unit Name..."> --}}

                                <select class="form-select shadow-none" aria-label="Default select example"
                                    name="client_status" id="client_status" value="client_status">
                                    {{-- <option selected>Select Condition</option> --}}
                                    <option value="Pending">Pending</option>
                                    <option value="Approved">Approved</option>
                                    <option value="Rejected">Rejected</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mt-1">
                            {{-- <div class="col-md-12">
                                <label class="form-label">Value <b class="text-danger">*</b></label>
                                <input type="text" class="form-control" name="value" id="unit_value"
                                    placeholder="Enter Unit Value..." onkeyup="edit_cal_sub_unit_price()" required>
                            </div> --}}

                        </div>

                        {{-- <div class="col-md-12">
                            <select class="form-select shadow-none" aria-label="Default select example"
                                name="productCondition" id="productCondition" value="">
                                <option selected>Select Condition</option>
                                <option value="Pending">Pending</option>
                                <option value="Approved">Approved</option>
                                <option value="Rejected">Rejected</option>
                            </select>
                        </div> --}}

                        {{-- <div class="row mt-1">
                            <div class="col-md-12">
                                <label class="form-label" for="edit_product_price">Price <b
                                        class="text-danger">*</b></label>
                                <input type="number" class="form-control" name="price" id="edit_product_price"
                                    data-price="" onchange="edit_cal_sub_unit_price()" required
                                    placeholder="Enter Price...">
                            </div>
                        </div> --}}
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-success" type="submit">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>
