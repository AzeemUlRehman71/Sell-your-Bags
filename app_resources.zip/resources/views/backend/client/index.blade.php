@extends('backend.layouts.layout')

@section('headInlineTag')

{{-- Write Style,link external CSS files --}}
<style>
   /* Gul here
                                Display eXport button hide via css */
   .buttons-collection {

      display: none;

   }
   table.dataTable>thead .sorting:before, table.dataTable>thead .sorting_asc:before, table.dataTable>thead .sorting_desc:before, table.dataTable>thead .sorting_asc_disabled:before, table.dataTable>thead .sorting_desc_disabled:before {
      right: 0em !important;
      content: "" !important;
   }
   table.dataTable>thead .sorting:after, table.dataTable>thead .sorting_asc:after, table.dataTable>thead .sorting_desc:after, table.dataTable>thead .sorting_asc_disabled:after, table.dataTable>thead .sorting_desc_disabled:after {
      right: 0em !important;
      content: "" !important;
   }
</style>

@endsection

@section('pageName', __('Sell Your Bags'))
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('home') }}">Home</a></li>
<li class="breadcrumb-item active">{{ __('Pos') }}</li>
@endSection

@php
if(Auth::user()->user_role != 'option_select'){
$data = json_decode(@$data,true)[0] ? json_decode(@$data,true)[0] : '';
$view = @$data['view'] ? @$data['view'] : '';
$changeStatus = @$data['change_status'] ? @$data['change_status'] : '';
$edit = @$data['edit'] ? @$data['edit'] : '';
}
@endphp

@section('content')

<section id="basic-datatable">
   <div class="row">
      <div class="col-12">
         <div class="card">
            <div class="card-datatable">
               <table class="datatables-basic table table-bordered hover">
                  <thead>
                     <tr>
                        <th width="8%">PO#</th>
                        <th>Name</th>
                        <th width="30%">Description</th>
                        <th class="d-none">Email</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>User Created</th>
                     </tr>
                  </thead>
                  <tbody>
                     @foreach ($list as $item)
                     @php
                        $onclickEvent = '';
                        if (Auth::user()->user_role != 'option_select' && $view == 1) {
                           $onclickEvent = "window.location.href='". route('client.view', ['id' => $item->id]) ."'";
                           $onclickEvent = 'onclick='. $onclickEvent;
                        }
                     @endphp

                     <tr class="cursor-pointer" {{ $onclickEvent }}>
                        <td>{{ $item->po_number }}</td>
                        <td>{{ $item->name }}</td>
                        <td>
                           {{ $item->product->implode('name', "\n") }}
                        </td>
                        <td class="d-none">{{ $item->email }}</td>
                        <td>{{ date('m-d-Y H:i:s', strtotime($item->created_at)) }}</td>
                        @if ($item->client_status == 'Approved')
                        <td><span class="badge rounded-pill badge-light-success" text-capitalized="">Approved</span>
                        </td>
                        @elseif($item->client_status == 'Pending')
                        <td><span class="badge rounded-pill badge-light-secondary" text-capitalized="">Pending</span>
                        </td>
                        @else
                        <td><span class="badge rounded-pill badge-light-danger" text-capitalized="">Rejected</span></td>
                        @endif
                        <td>{{ $item->user_create }}</td>
                     </tr>
                     @endforeach
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</section>

{{-- Include Delete Role Modal --}}
{{-- @include('user.delete') --}}
@include('backend.client.modal.edit_product_unit')
{{-- @include('backend.client.modal.edit_product_details') --}}
@endsection

@section('jsOutside')

{{-- Write script,link external JS files --}}
{{-- Include Custom js File --}}
@include('backend.custom_js.init_js')
@endsection