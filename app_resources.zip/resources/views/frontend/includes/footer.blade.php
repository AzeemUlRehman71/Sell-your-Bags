<div class="row justify-content-between pb-5 bg-white px-3">
    <div class="col-md-4">
        <p class="fw-bold mb-1">FOR QURIES CONTACT US:</p>
        <p class="contact-color mb-1">
            <i class="bi bi-telephone-forward" style="font-size: 1rem; color: #206c5f"></i>
            +9552525-525
        </p>
        <p class="mb-1">
            <i class="bi bi-envelope-fill" style="font-size: 1rem; color: #206c5f"></i>
            mail@mail.com
        </p>
    </div>
    <div class="col-md-4 d-grid">
        <button class="btn btn-success btn-lg" type="submit">SUBMIT</button>
    </div>
</div>